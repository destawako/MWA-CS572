const mongoose = require("mongoose");
const Student = mongoose.model("Student");

var ObjectId= require("mongodb").ObjectId;

module.exports.addOneAddress = function(req, res){
    console.log("Address to add a Student");
    const studentId = req.params.studentId;
    if(req.body.street && req.body.city && req.body.state && req.body.zipCode){
        Student.findById(studentId).exec(function(err, student){
            const response =  {
                status : 204,
                message : student
            }
            if(err){
                response.status=400;
                response.message = err;
            } else if(!student){
                response.status=404;
                response.message = {"message": "Student ID not found"};
            } 
    
            //this means somethoing went wrong
            if(response.status != 204){
                res.status(response.status).json(response.message);
            }else{
                //we got a game, now we neet to update it
                console.log(student.addresses[0]);
                if(student.addresses[0] ==  ''  )
                    student.addresses = [{"street":req.body.street,"city":req.body.city,"state": req.body.state, "zipCode":req.body.zipCode}];
                else
                    student.addresses = student.addresses.concat([{"street":req.body.street,"city":req.body.city,"state": req.body.state, "zipCode":req.body.zipCode}]);
                
                
                // game.reviews.rating  = parseInt(req.body.rating);
                // game.reviews.review = req.body.review;
                console.log(response.status);
                console.log(req.body.name);
                console.log(student.addresses)
                student.save(function(err, updateAddress) {
                    response.message = updateAddress;
                    if(err){
                        console.log("500 error reached");
                        response.status = 500;
                        response.message = err;
                    }
                    res.status(response.status).json(response.message);
                });
            }
    
        });
    } else{
        console.log("Data missing from POST body");
        res.status(400).json({error:"Required data missing from POST"});
    }
}


// getting all the addresses from the DB
module.exports.getAllAddresses = function(req,res){
    
    console.log("Gettinng One Students Addresses...");
    var studentId = req.params.studentId;
    Student.findById(studentId).select("addresses").exec(function(err,addresses){
        res.status(200).json(addresses);
    });
}

module.exports.updateOneAddress = function(req, res){
    console.log("Getting one Address");
    var studentId = req.params.studentId;
    var addressId = req.params.addressId;
    var address;
    console.log(addressId);

    Student.findById(studentId).exec(function(err,student){
        console.log(student);
        address = student.addresses.id(addressId);
        console.log(student);
        const response ={
            status:204,
            message:student
        };
        
        if(err){
            response.status = 400;
            response.message = err;
            console.log(err);
            return;
        }
        else if(!student || !address){                        // ("Result Checking ")
            response.status =404;
            response.message = {"message":"Address or Student ID not found."};
        }

        if(response.status != 204){
            res.status(response.status).json(response.message);
        }else{
            //we got a game, now we neet to update it
            console.log(student.name);
            address.street = req.body.street;
            address.city = req.body.city;
            address.state = req.body.state;
            address.zipCode = parseInt(req.body.zipCode);
            student.save(function(err, updateStudent) {
                response.message = updateStudent;
                if(err){
                    response.status = 500;
                    response.message = err;
                }
                res.status(response.status).json(response.message);
            });
        }
        
    });
}

module.exports.deleteOneAddress = function(req, res){
    console.log("Delleting one address");
    var studentId = req.params.studentId;
    var addressId = req.params.addressId;

    Student.findById(studentId).exec(function(err,student){
        address = student.addresses.id(addressId);
        console.log(address);
        const response ={
            status:204,
            message:address
        };
        
        if(err){
            response.status = 400;
            response.message = err;
            console.log(err);
            return;
        }
        else if(!student || !address){                        // ("Result Checking ")
            response.status =404;
            response.message = {"message":"Student or Address ID not found."};
        }
        
        res.status(response.status).json(response.message);
        address.remove();
        student.save(function(err, updateStudent) {
            response.message = updateStudent;
        });   
        
    });
}

//getting one address from the DB
module.exports.getOneAddress = function (req, res) {
    var studentId = req.params.studentId;
    var addressId=req.params.addressId;
    console.log("GET addressId "+addressId+ " for Student "+studentId);
    Student.findById(studentId).select("addresses").exec(function (err, student) {
      console.log(student.addresses);
      var address=student.addresses.id(addressId);
        var response = {
        status: 200,
        message: address
      };
      if (err) {
        console.log("Error finding address");
        response.status = 500;
        response.message = err;
      } else if (!address) {
        response.status = 404;
        response.message = { message: "Address ID not foud" };
      }
      res.status(response.status).json(response.message);
    });
  };