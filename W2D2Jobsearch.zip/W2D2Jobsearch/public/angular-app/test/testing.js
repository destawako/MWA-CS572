angular.module("jobSearchApp").controller("testController", testController);

function testController() {
    var vm = this;
    vm.title = "Testing how Angular works";
};